from bs4 import BeautifulSoup
html_doc = 