print('hello python!')
print('hallo!')
print('Guten Tag')
